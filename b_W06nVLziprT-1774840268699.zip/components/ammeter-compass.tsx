"use client"

import { motion } from "framer-motion"
import { useMemo } from "react"

interface AmmeterCompassProps {
  weight: number
  maxWeight?: number
  minWeight?: number
  status?: "stable" | "measuring" | "overload" | "disconnected"
}

export function AmmeterCompass({
  weight,
  maxWeight = 200,
  minWeight = 0,
  status = "stable",
}: AmmeterCompassProps) {
  // Calculate needle angle
  // 0kg at top (12 o'clock), 200kg at bottom (6 o'clock)
  // This is a right-side semicircle: 0 degrees = pointing up, 180 degrees = pointing down
  const needleAngle = useMemo(() => {
    const clampedWeight = Math.max(minWeight, Math.min(weight, maxWeight))
    const percentage = (clampedWeight - minWeight) / (maxWeight - minWeight)
    // 0 to 180 degrees (top to bottom on the right side)
    return percentage * 180
  }, [weight, maxWeight, minWeight])

  // Calculate gradient color based on weight (light cyan to dark navy)
  const getGradientColor = useMemo(() => {
    const percentage = Math.min(weight / maxWeight, 1)
    const r = Math.round(0 + percentage * (0 - 0))
    const g = Math.round(229 - percentage * (229 - 60))
    const b = Math.round(255 - percentage * (255 - 143))
    return `rgb(${r}, ${g}, ${b})`
  }, [weight, maxWeight])

  // Generate tick marks - 0 at top, 200 at bottom (right side arc)
  const ticks = useMemo(() => {
    const tickArray = []
    const step = maxWeight / 10
    for (let i = 0; i <= 10; i++) {
      const value = minWeight + (step * i)
      // 0 degrees at top, 180 at bottom (in standard math coords)
      // But SVG uses -90 as up, so we map: 0kg = -90deg, 200kg = +90deg
      const angle = -90 + (i * 18)
      const isMajor = i % 2 === 0
      tickArray.push({ value, angle, isMajor })
    }
    return tickArray
  }, [maxWeight, minWeight])

  // Generate arc segments for gradient effect
  const arcSegments = useMemo(() => {
    const segments = []
    const totalSegments = 20
    for (let i = 0; i < totalSegments; i++) {
      const percentage = i / totalSegments
      // Arc from -90 (top) to +90 (bottom) on the RIGHT side
      const startAngle = -90 + (percentage * 180)
      const endAngle = -90 + ((i + 1) / totalSegments * 180)
      // Color gradient from light to dark
      const lightness = 85 - (percentage * 60)
      const hue = 195 - (percentage * 30)
      segments.push({
        startAngle,
        endAngle,
        color: `oklch(${lightness}% 0.15 ${hue})`,
      })
    }
    return segments
  }, [])

  const statusColors = {
    stable: "#00E5FF",
    measuring: "#FFB300",
    overload: "#FF5252",
    disconnected: "#757575",
  }

  // Center point - positioned on left so the arc extends to the right
  const centerX = 60
  const centerY = 200

  return (
    <div className="relative w-full max-w-sm mx-auto">
      <svg
        viewBox="0 0 300 400"
        className="w-full h-auto"
        style={{ filter: `drop-shadow(0 0 20px ${getGradientColor}40)` }}
      >
        <defs>
          <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="50%" stopColor="#009DFF" />
            <stop offset="100%" stopColor="#003C8F" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Outer decorative ring - semicircle on the right side */}
        <path
          d={`M ${centerX} ${centerY - 160} A 160 160 0 0 1 ${centerX} ${centerY + 160}`}
          fill="none"
          stroke="rgba(255,255,255,0.05)"
          strokeWidth="30"
        />

        {/* Gradient arc background */}
        {arcSegments.map((segment, index) => {
          const innerRadius = 130
          const outerRadius = 155
          const startRad = (segment.startAngle * Math.PI) / 180
          const endRad = (segment.endAngle * Math.PI) / 180
          
          const x1Inner = centerX + innerRadius * Math.cos(startRad)
          const y1Inner = centerY + innerRadius * Math.sin(startRad)
          const x2Inner = centerX + innerRadius * Math.cos(endRad)
          const y2Inner = centerY + innerRadius * Math.sin(endRad)
          
          const x1Outer = centerX + outerRadius * Math.cos(startRad)
          const y1Outer = centerY + outerRadius * Math.sin(startRad)
          const x2Outer = centerX + outerRadius * Math.cos(endRad)
          const y2Outer = centerY + outerRadius * Math.sin(endRad)

          return (
            <path
              key={index}
              d={`M ${x1Inner} ${y1Inner} 
                  A ${innerRadius} ${innerRadius} 0 0 1 ${x2Inner} ${y2Inner}
                  L ${x2Outer} ${y2Outer}
                  A ${outerRadius} ${outerRadius} 0 0 0 ${x1Outer} ${y1Outer}
                  Z`}
              fill={segment.color}
              opacity={0.8}
            />
          )
        })}

        {/* Tick marks and labels */}
        {ticks.map((tick, index) => {
          const rad = (tick.angle * Math.PI) / 180
          const innerR = tick.isMajor ? 110 : 118
          const outerR = 125
          const labelR = 175
          
          const x1 = centerX + innerR * Math.cos(rad)
          const y1 = centerY + innerR * Math.sin(rad)
          const x2 = centerX + outerR * Math.cos(rad)
          const y2 = centerY + outerR * Math.sin(rad)
          const labelX = centerX + labelR * Math.cos(rad)
          const labelY = centerY + labelR * Math.sin(rad)

          return (
            <g key={index}>
              <line
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={tick.isMajor ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0.4)"}
                strokeWidth={tick.isMajor ? 2 : 1}
              />
              {tick.isMajor && (
                <text
                  x={labelX}
                  y={labelY}
                  fill="rgba(255,255,255,0.7)"
                  fontSize="14"
                  fontFamily="var(--font-mono)"
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontWeight="500"
                >
                  {Math.round(tick.value)}
                </text>
              )}
            </g>
          )
        })}

        {/* Center decoration */}
        <circle cx={centerX} cy={centerY} r="25" fill="rgba(0,0,0,0.8)" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
        <circle cx={centerX} cy={centerY} r="18" fill={statusColors[status]} filter="url(#glow)" />
        <circle cx={centerX} cy={centerY} r="12" fill="rgba(0,0,0,0.5)" />

        {/* Needle */}
        <motion.g
          style={{ transformOrigin: `${centerX}px ${centerY}px` }}
          initial={{ rotate: -90 }}
          animate={{ rotate: needleAngle - 90 }}
          transition={{ type: "spring", stiffness: 60, damping: 15 }}
        >
          {/* Needle shadow */}
          <polygon
            points={`${centerX + 120},${centerY} ${centerX + 5},${centerY - 5} ${centerX + 5},${centerY + 5}`}
            fill="rgba(0,0,0,0.3)"
            transform="translate(2, 2)"
          />
          {/* Main needle - pointing right */}
          <polygon
            points={`${centerX + 125},${centerY} ${centerX + 5},${centerY - 6} ${centerX + 5},${centerY + 6}`}
            fill="url(#gaugeGradient)"
            filter="url(#glow)"
          />
          {/* Needle highlight */}
          <polygon
            points={`${centerX + 120},${centerY} ${centerX + 20},${centerY - 3} ${centerX + 15},${centerY}`}
            fill="rgba(255,255,255,0.3)"
          />
        </motion.g>

        {/* Center cap */}
        <circle cx={centerX} cy={centerY} r="8" fill="#0a0a0f" stroke={getGradientColor} strokeWidth="2" />

        {/* Unit label */}
        <text
          x={centerX}
          y={centerY + 50}
          fill="rgba(255,255,255,0.6)"
          fontSize="16"
          fontFamily="var(--font-sans)"
          textAnchor="middle"
          fontWeight="600"
        >
          kg
        </text>
      </svg>
    </div>
  )
}
